"""Recompute the read-level, alignment and quantification metrics of the case study.

Inputs (from the platform exports):
  01_quality_control/multiqc_report_pretrim_qc.html     FastQC on the raw reads
  01_quality_control/multiqc_report_posttrim_qc.html    FastQC on the trimmed paired reads
  01_quality_control/multiqc_report_full_pipeline.html  Trimmomatic and STAR logs
  02_alignment_and_quantification/samtools-flagstat-table.csv
  02_alignment_and_quantification/count_matrix_statistics.json   HTSeq-count statistics
Outputs:
  results/per_file_quality.csv    mean and lowest per-position quality and highest adapter content per FASTQ file
  results/per_sample_metrics.csv  one row per sample
and a printed summary in the form mean ± standard deviation (range).
"""
import json
import os
import re

import pandas as pd
from scipy.stats import mannwhitneyu

from omx_utils import SAMPLES, data_args, general_stats, groups, multiqc_plot_data, summary

a = data_args(__doc__.splitlines()[0])
qc = os.path.join(a.data, "01_quality_control")
aq = os.path.join(a.data, "02_alignment_and_quantification")
pre = multiqc_plot_data(os.path.join(qc, "multiqc_report_pretrim_qc.html"))
post = multiqc_plot_data(os.path.join(qc, "multiqc_report_posttrim_qc.html"))
full = multiqc_plot_data(os.path.join(qc, "multiqc_report_full_pipeline.html"))
grp = groups(a.data)

# ---------------------------------------------------------------- per FASTQ file
def per_file(pd_, suffix):
    """Mean and minimum of the FastQC per-position mean quality, and the highest adapter content."""
    lines = {l["name"]: [y for _, y in l["pairs"]] for l in pd_["fastqc_per_base_sequence_quality_plot"]["datasets"][0]["lines"]}
    adapt = {}
    for l in pd_["fastqc_adapter_content_plot"]["datasets"][0]["lines"]:
        f = l["name"].split(" - ")[0]
        adapt[f] = max(adapt.get(f, 0), max(y for _, y in l["pairs"]))
    rows = {}
    for s in SAMPLES:
        for mate in (1, 2):
            key = f"{s}_{mate}{suffix}"
            q = lines[key]
            rows[f"{s}_{mate}"] = {"mean_quality": sum(q) / len(q), "lowest_position_quality": min(q), "max_adapter_pct": adapt[key]}
    return pd.DataFrame(rows).T

pf = per_file(pre, "").add_prefix("raw_").join(per_file(post, "_paired").add_prefix("trimmed_"))
pf.index.name = "file"
pf.to_csv(os.path.join(a.out, "per_file_quality.csv"))

# ---------------------------------------------------------------- per sample
gpre, gpost, gfull = general_stats(pre), general_stats(post), general_stats(full)
trim = full["trimmomatic_plot"]["datasets"][0]
trim_n = {c["name"]: dict(zip(trim["samples"], c["data"])) for c in trim["cats"]}
trim_pct = {c["name"]: dict(zip(trim["samples"], c["data_pct"])) for c in trim["cats"]}
star = full["star_alignment_plot"]["datasets"][0]
star_n = {c["name"]: dict(zip(star["samples"], c["data"])) for c in star["cats"]}
star_tab = full["star_summary_table"]["datasets"][0]["violin_value_by_sample_by_metric"]
length = {l["name"]: l["pairs"] for l in post["fastqc_sequence_length_distribution_plot"]["datasets"][0]["lines"]}
flag = pd.read_csv(os.path.join(aq, "samtools-flagstat-table.csv"))
flag.columns = [c.strip("﻿") for c in flag.columns]
flag = flag.assign(Run=flag.Sample.str.replace("_markdup", "")).set_index("Run")
txt = re.sub(r",\s*\]", "]", open(os.path.join(aq, "count_matrix_statistics.json")).read())   # tolerate a trailing comma
htseq = {r["sample_name"].replace("_count.matrix", ""): r for r in json.loads(txt)}

rows = []
for s in SAMPLES:
    r = {"Run": s, "Group": grp[s]}
    r["raw_read_pairs_million"] = gpre["fastqc-total_sequences"][s + "_1"]
    r["raw_gc_R1_pct"] = gpre["fastqc-percent_gc"][s + "_1"]
    r["raw_duplication_R1_pct"] = gpre["fastqc-percent_duplicates"][s + "_1"]
    r["trim_both_mates_kept_pct"] = trim_pct["Surviving Reads"][s]
    r["trim_forward_only_pct"] = trim_pct["Forward Only Surviving"][s]
    r["trim_reverse_only_pct"] = trim_pct["Reverse Only Surviving"][s]
    r["trim_dropped_pct"] = trim_pct["Dropped"][s]
    r["trim_pairs_kept_million"] = trim_n["Surviving Reads"][s] / 1e6
    k1 = s + "_1_paired"
    r["trimmed_mean_length_R1_bp"] = gpost["fastqc-avg_sequence_length"][k1]
    hist = length[k1]
    r["trimmed_full_length_R1_pct"] = 100 * sum(y for x, y in hist if x >= 101) / sum(y for _, y in hist)
    tot = gfull["star-total_reads"][s]
    r["star_input_pairs_million"] = tot
    r["star_aligned_pct"] = gfull["star-mapped_percent"][s]
    r["star_unique_pct"] = gfull["star-uniquely_mapped_percent"][s]
    r["star_multiple_loci_pct"] = 100 * gfull["star-multimapped"][s] / tot
    r["star_too_short_pct"] = 100 * star_n["Unmapped: too short"][s] / (tot * 1e6)
    r["star_mismatch_rate_pct"] = star_tab["star-mismatch_rate"][s]
    r["star_splices_million"] = star_tab["star-num_splices"][s]
    r["star_annotated_splices_pct"] = 100 * star_tab["star-num_annotated_splices"][s] / star_tab["star-num_splices"][s]
    f = flag.loc[s]
    primary = f["Total Reads"] - f["Secondary Alignments"]
    r["duplicates_pct_of_primary"] = 100 * f["Duplicates"] / primary
    h = htseq[s]
    counted = h["total_assigned_reads"] + h["no_feature"] + h["ambiguous"] + h["alignment_not_unique"] + h["too_low_aQual"] + h["not_aligned"]
    r["htseq_counted_pairs_million"] = counted / 1e6
    r["htseq_assigned_pairs_million"] = h["total_assigned_reads"] / 1e6
    r["htseq_assignment_rate_pct"] = h["assignment_rate"]      # assigned / (assigned + no_feature + ambiguous)
    r["htseq_assigned_pct_of_counted"] = 100 * h["total_assigned_reads"] / counted
    r["htseq_no_feature_pct_of_counted"] = 100 * h["no_feature"] / counted
    r["htseq_ambiguous_pct_of_counted"] = 100 * h["ambiguous"] / counted
    r["htseq_not_unique_pct_of_counted"] = 100 * h["alignment_not_unique"] / counted
    r["features_with_counts"] = h["genes_with_counts"]
    rows.append(r)
ps = pd.DataFrame(rows)
ps.to_csv(os.path.join(a.out, "per_sample_metrics.csv"), index=False)

# ---------------------------------------------------------------- summary as reported
print("Per file (78 FASTQ files)")
for c, d in [("raw_mean_quality", 1), ("raw_lowest_position_quality", 1), ("raw_max_adapter_pct", 1),
             ("trimmed_mean_quality", 1), ("trimmed_lowest_position_quality", 1), ("trimmed_max_adapter_pct", 1)]:
    print(f"  {c:34s} {summary(pf[c], d)}")
print("Per sample (39 samples)")
for c in ps.columns[2:]:
    d = 2 if c.startswith("star_mismatch") else (0 if c == "features_with_counts" else 1)
    print(f"  {c:34s} {summary(ps[c], d)}")
by = ps.groupby("Group")
print("By group, mean ± standard deviation")
for c in ["raw_read_pairs_million", "trim_both_mates_kept_pct", "star_unique_pct"]:
    print(f"  {c:34s} " + ", ".join(f"{g} {by[c].mean()[g]:.1f} ± {by[c].std()[g]:.1f}" for g in ("IPF", "Control")))
u = mannwhitneyu(ps[ps.Group == "IPF"].star_unique_pct, ps[ps.Group == "Control"].star_unique_pct, alternative="two-sided")
print(f"  Mann-Whitney test of unique mapping, IPF against control: P = {u.pvalue:.2g}")
