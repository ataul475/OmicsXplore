"""Shared helpers for the OmicsXplore case-study scripts.

The scripts read the files that the OmicsXplore platform exported for the
GSE92592 case study (the six archives 01_quality_control.zip to
06_gene_fusions.zip). Unpack the archives into one data folder, so that it
contains the folders 01_quality_control, 02_alignment_and_quantification,
03_sample_metadata, 04_differential_expression, 05_alternative_splicing and
06_gene_fusions, and pass that folder with --data (default: ./data).
"""
import argparse
import base64
import gzip
import json
import os
import re

import pandas as pd

SAMPLES = [f"SRR51209{i:02d}" for i in range(2, 41)]   # SRR5120902 to SRR5120940


def data_args(description):
    """Command-line options shared by all scripts."""
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--data", default="data", help="folder that holds the unpacked platform exports (default: ./data)")
    p.add_argument("--out", default="results", help="folder for the output tables (default: ./results)")
    a = p.parse_args()
    if not os.path.isdir(os.path.join(a.data, "03_sample_metadata")):
        p.error(f"{a.data} does not contain the unpacked exports (03_sample_metadata not found)")
    os.makedirs(a.out, exist_ok=True)
    return a


def multiqc_plot_data(html_path):
    """Return the plot data that MultiQC (version 1.2x and later) embeds in its HTML report.

    MultiQC stores the data of every plot as gzip-compressed, base64-encoded JSON in a
    <script id="mqc_compressed_plotdata"> element.
    """
    with open(html_path, encoding="utf-8", errors="ignore") as fh:
        html = fh.read()
    m = re.search(r'<script[^>]*id="mqc_compressed_plotdata"[^>]*>(.*?)</script>', html, re.S)
    if m is None:
        raise ValueError(f"no embedded plot data found in {html_path}")
    return json.loads(gzip.decompress(base64.b64decode(m.group(1).strip())))


def general_stats(plot_data):
    """Values of the MultiQC general statistics table, as {metric: {sample: value}}."""
    return plot_data["general_stats_table"]["datasets"][0]["violin_value_by_sample_by_metric"]


def groups(data_dir):
    """Sample groups from the metadata table used by the DEG analysis module."""
    meta = pd.read_csv(os.path.join(data_dir, "03_sample_metadata", "IPF_meta_data.csv")).set_index("Sample-name")["Group"]
    return meta.map(lambda g: "Control" if g == "Control" else "IPF")


def summary(series, digits=1):
    """Mean ± standard deviation (range), as reported in the article."""
    f = f"{{:.{digits}f}}"
    return f"{f.format(series.mean())} ± {f.format(series.std())} ({f.format(series.min())} to {f.format(series.max())})"
