"""Tabulate the candidate fusion events from the Arriba visualisations of the case study.

Input (from the platform exports):
  06_gene_fusions/SRR51209xx_fusions.pdf   Arriba 2.5.0 visualisations, one page per event
Output:
  results/arriba_fusions_table.csv   one row per event, with partners, breakpoints, supporting reads,
                                     predicted reading frame and retained protein domains
and a printed summary. The values are read from the text layer of the PDF pages.
"""
import glob
import os
import re

import pandas as pd
from pypdf import PdfReader

from omx_utils import data_args, groups

a = data_args(__doc__.splitlines()[0])
grp = groups(a.data)
rows = []
for path in sorted(glob.glob(os.path.join(a.data, "06_gene_fusions", "*_fusions.pdf"))):
    sample = os.path.basename(path).replace("_fusions.pdf", "")
    for page_no, page in enumerate(PdfReader(path).pages, 1):
        t = page.extract_text() or ""
        lines = t.split("\n")
        chr_a = re.match(r"chromosome (\S+)", lines[0]).group(1)
        m = re.match(r"(\S+)chromosome (\S+)", lines[1])
        band_a, chr_b, band_b = m.group(1), m.group(2), lines[2].strip()
        block = "\n".join(lines[3:12])
        mb = re.search(r"(chr[0-9XYM]+:\d+)breakpoint2\s*\n?(chr[0-9XYM]+:\d+)", block)
        bp1, bp2 = mb.group(1), mb.group(2)
        head = re.sub(r"ENST\d{11}", "\n", block[:mb.start()]).replace("breakpoint1", "\n")
        head = re.sub(r"(ENSG\d{11})(?=ENSG)", r"\1\n", head)
        genes = []
        for tok in (x for x in re.split(r"\s+", head) if x):
            if tok not in genes:
                genes.append(tok)
        if len(genes) == 1:                       # both breakpoints in one gene
            genes = genes * 2
        g1, g2 = (g.replace("−", "-").replace("IGKCIGKC", "IGKC") for g in genes[:2])
        split1 = int(re.search(r"Split reads at breakpoint1 = (\d+)", t).group(1))
        split2 = int(re.search(r"Split reads at breakpoint2 = (\d+)", t).group(1))
        disc = int(re.search(r"Discordant mates = (\d+)", t).group(1))
        if re.search(r"in.frame fusion", t): frame = "in-frame"
        elif re.search(r"out.of.frame fusion", t): frame = "out-of-frame"
        elif "not protein" in t: frame = "non-coding partner"
        elif "No protein domains" in t: frame = "no domains retained"
        else: frame = "not stated"
        dom = re.search(r"RETAINED PROTEIN DOMAINS\s*(.*?)\s*SUPPORTING READ COUNT", t, re.S)
        domains = re.sub(r"\s+", " ", dom.group(1)).replace("in−frame fusion", "").replace("out−of−frame fusion", "").strip() if dom else ""
        rows.append(dict(sample=sample, group=grp[sample], page=page_no, gene1=g1, gene2=g2, chr1=chr_a, band1=band_a, bp1=bp1,
                         chr2=chr_b, band2=band_b, bp2=bp2, split1=split1, split2=split2, discordant=disc,
                         total_support=split1 + split2 + disc, reading_frame=frame, intrachromosomal=chr_a == chr_b,
                         retained_domains=domains))
d = pd.DataFrame(rows)
d.to_csv(os.path.join(a.out, "arriba_fusions_table.csv"), index=False)

per_sample = d.groupby("sample").size().reindex(sorted(grp.index), fill_value=0)
pairs = d.apply(lambda r: tuple(sorted([r.gene1, r.gene2])), axis=1).nunique()
print(f"events {len(d)} in {d['sample'].nunique()} samples (IPF {int((d.group == 'IPF').sum())}, control {int((d.group == 'Control').sum())}), "
      f"median per sample {int(per_sample.median())}")
print(f"distinct gene pairs {pairs}, intrachromosomal {int(d.intrachromosomal.sum())}, both breakpoints in one gene {int((d.gene1 == d.gene2).sum())}")
print("reading frame:", d.reading_frame.value_counts().to_dict())
print(f"supporting reads, median {d.total_support.median():.0f}; events with ten or more reads {int((d.total_support >= 10).sum())}, "
      f"of which in frame {int(((d.total_support >= 10) & (d.reading_frame == 'in-frame')).sum())}")
print(f"events with at least one retained protein domain {int((d.retained_domains.fillna('') != '').sum())}")
