"""Repeat the differential expression test of the case study outside the platform.

Inputs (from the platform exports):
  02_alignment_and_quantification/annotated_counts_IPF.csv   annotated count matrix
  03_sample_metadata/IPF_meta_data.csv                       sample to group table
  04_differential_expression/deseq2_full_results.csv         the platform's result, for comparison
Settings, as in the platform: PyDESeq2 0.5.4 with its default settings, design ~Condition,
contrast control against IPF (control as the numerator), features with no reads removed before
fitting. Wald test P values are adjusted by the Benjamini and Hochberg method after the default
independent filtering of PyDESeq2. Features with a baseMean below 10 are set aside after fitting,
and differential expression is called at an adjusted P below 0.05 and an absolute log2 fold
change above 0.5.
Outputs:
  results/reproduction_all_features.csv   PyDESeq2 result for every fitted feature
  results/reproduction_comparison.csv     the 10,484 tested features, platform against re-run
and a printed summary of the agreement.
"""
import os
import warnings

import pandas as pd
from pydeseq2.dds import DeseqDataSet
from pydeseq2.default_inference import DefaultInference
from pydeseq2.ds import DeseqStats

from omx_utils import data_args

warnings.filterwarnings("ignore")
a = data_args(__doc__.splitlines()[0])

counts = pd.read_csv(os.path.join(a.data, "02_alignment_and_quantification", "annotated_counts_IPF.csv"))
samples = [c for c in counts.columns if c.startswith("SRR")]
counts = counts.set_index("Gene")[samples].T                  # samples by features
meta = pd.read_csv(os.path.join(a.data, "03_sample_metadata", "IPF_meta_data.csv")).set_index("Sample-name")
meta["Condition"] = meta["Group"].map({"Idiopathic Pulmonary Fibrosis": "IPF", "Control": "Control"})
meta = meta.loc[counts.index]
counts = counts.loc[:, counts.sum(axis=0) > 0]
print(f"samples {counts.shape[0]} (IPF {int((meta.Condition == 'IPF').sum())}, control {int((meta.Condition == 'Control').sum())}), features with reads {counts.shape[1]}")

inference = DefaultInference(n_cpus=os.cpu_count() or 1)
dds = DeseqDataSet(counts=counts, metadata=meta, design="~Condition", inference=inference, quiet=True)
dds.deseq2()
stats = DeseqStats(dds, contrast=["Condition", "Control", "IPF"], inference=inference, quiet=True)
stats.summary()
res = stats.results_df
res.to_csv(os.path.join(a.out, "reproduction_all_features.csv"))
print(f"features with an adjusted P after independent filtering {int(res.padj.notna().sum())}")

tested = res[res.baseMean >= 10]
sig = tested[(tested.padj < 0.05) & (tested.log2FoldChange.abs() > 0.5)]
print(f"tested {len(tested)}, differentially expressed {len(sig)}: "
      f"up-regulated {(sig.log2FoldChange > 0).sum()} and down-regulated {(sig.log2FoldChange < 0).sum()} in control relative to IPF")

plat = pd.read_csv(os.path.join(a.data, "04_differential_expression", "deseq2_full_results.csv")).set_index("gene_ids")
j = plat[["baseMean", "log2FoldChange", "padj"]].join(tested[["baseMean", "log2FoldChange", "padj"]], rsuffix="_rerun", how="outer")
j["called_platform"] = (j.padj < 0.05) & (j.log2FoldChange.abs() > 0.5)
j["called_rerun"] = (j.padj_rerun < 0.05) & (j.log2FoldChange_rerun.abs() > 0.5)
j["padj_difference"] = (j.padj - j.padj_rerun).abs()
j.index.name = "feature"
j.to_csv(os.path.join(a.out, "reproduction_comparison.csv"))
both = j.dropna(subset=["baseMean", "baseMean_rerun"])
print(f"features in both tables {len(both)}, only in the platform table {int(j.baseMean_rerun.isna().sum())}, only in the re-run {int(j.baseMean.isna().sum())}")
print(f"features called differently {int((both.called_platform != both.called_rerun).sum())}")
print(f"largest difference in baseMean {(both.baseMean - both.baseMean_rerun).abs().max():.1e}, "
      f"in log2 fold change {(both.log2FoldChange - both.log2FoldChange_rerun).abs().max():.1e}")
over = both[both.padj_difference > 0.001]
print(f"adjusted P values differing by more than 0.001: {len(over)} features, largest difference {both.padj_difference.max():.3f}")
