# OmicsXplore case study: analysis scripts

These scripts recompute, from the files that the OmicsXplore platform exported for the
GSE92592 case study, the summary values, the independent re-run of the differential
expression test and the fusion tables reported in the article and its supplementary
material. They do not contain the OmicsXplore platform itself, which is proprietary.

## Contents

| Script | What it does | Results in the article |
| --- | --- | --- |
| `omx_utils.py` | Shared helpers, including reading the plot data that MultiQC embeds in its HTML reports | |
| `01_summarise_read_metrics.py` | Per-file read quality and per-sample trimming, alignment, duplicate and counting metrics | Section 3.1 and Table 3, Supplementary Tables S3a to S3d |
| `02_reproduce_differential_expression.py` | Repeats the differential expression test with PyDESeq2 0.5.4 and compares it with the platform's result feature by feature | Sections 3.2 and 3.5, Supplementary Section S4 |
| `03_parse_arriba_visualisations.py` | Reads the candidate fusion events from the Arriba visualisations | Section 3.4, Supplementary Tables S7 to S9 |

## Requirements

Python 3.10 or later with the packages in `requirements.txt`:

```
pip install -r requirements.txt
```

The scripts were tested with Python 3.11, pandas 2.3.3, NumPy 2.4.4, SciPy 1.17.1,
pypdf 3.17.4 and PyDESeq2 0.5.4. PyDESeq2 must be version 0.5.4 to match the platform.

## Data

The scripts read the files that the platform exported for the case study. Either unpack
Supplementary Data S2 of the article (`OmicsXplore_Data_S2.zip`) and pass its folder with
`--data OmicsXplore_Data_S2`, or unpack the six archives of the GitHub repository
(https://github.com/ataul475/OmicsXplore), which are also archived on Zenodo
(https://doi.org/10.5281/zenodo.23507592), into one folder called `data`. Either way the folder
must hold the subfolders `01_quality_control` to `06_gene_fusions`.

## Running

```
python 01_summarise_read_metrics.py --data data --out results
python 02_reproduce_differential_expression.py --data data --out results
python 03_parse_arriba_visualisations.py --data data --out results
```

The first script takes a few seconds, and the second and third take one to two minutes each
on a laptop. Each script writes its tables to `results` and prints a summary.

## Expected results

- **Read metrics:** 48.3 ± 8.1 million read pairs per sample, 89.6 ± 2.0% of pairs kept
  after trimming, 98.2 ± 0.6% of retained pairs aligned, unique mapping of 69.5 ± 7.8% in IPF
  and 81.4 ± 5.6% in control samples (Mann-Whitney P = 1e-05), and an HTSeq-count
  assignment rate of 27.0 ± 1.5%.
- **Differential expression:** 33,877 features with reads, of which 22,054 pass the default
  independent filtering of PyDESeq2, 10,484 tested and 3,464 differentially expressed. Of these, 1,714 are up-regulated and 1,750 down-regulated in
  control relative to IPF, and no feature is called differently from the platform.
- **Gene fusions:** 271 candidate events in 38 samples, 54 predicted in frame and 45 out of
  frame, and 61 events with ten or more supporting reads.

Fold changes are given as control relative to IPF (control as the numerator), as exported by
the platform. Down-regulated features are therefore those raised in IPF.

## Licence

The scripts are released under the MIT licence (see `LICENSE`). The third-party tools used
by the platform remain under their own licences.
