Supplementary Data S2a and S2b
==============================

Article: OmicsXplore: A Fully Cloud-Based Platform for Automated, End-to-End
Bioinformatics Analysis Applied to RNA Sequencing of Idiopathic Pulmonary
Fibrosis Lung Tissue
Journal: Computer Methods and Programs in Biomedicine
Authors: Monishka Battula, Parth Mangal, Omkar Shinde, Sonali Chikhale,
Shovonlal Bhowmick, Saikh Mohammad Wabaidur and Md Ataul Islam


1. Description
--------------
These two archives hold the files that the OmicsXplore platform exported for
the case study of the article. The dataset is GSE92592 (BioProject PRJNA358081,
SRA study SRP095361), with 39 lung tissue samples. Twenty come from patients
with idiopathic pulmonary fibrosis (IPF, SRR5120902 to SRR5120921) and 19
from control donors (SRR5120922 to SRR5120940). The files are given as the
platform exported them, except where a note below says otherwise. They are
the source of the values reported in the article and in the Supplementary
Material.


2. Parts and size
-----------------
The exported files are supplied as two archives, so that neither exceeds
25 MB. Unpack both into the same place. Each creates the folder
OmicsXplore_Data_S2, and the two parts fill it together, because they hold
different subfolders and the same copy of this README.

  OmicsXplore_Data_S2a.zip   01_quality_control,
                             02_alignment_and_quantification,
                             03_sample_metadata,
                             04_differential_expression and
                             05_alternative_splicing. About 15 MB.
  OmicsXplore_Data_S2b.zip   06_gene_fusions, the 38 Arriba PDF files.
                             About 17 MB.

Together they hold 62 data files and this README in six folders, about 61 MB
unpacked.


3. Platform
-----------
The files were produced on the OmicsXplore cloud platform of SilicoScientia
Private Limited. They are ordinary data files and can be opened on Windows,
macOS or Linux.


4. Environment
--------------
HTML reports open in any current web browser. CSV files open in a
spreadsheet program, in Python (pandas) or in R. The JSON file opens in any
text editor. PNG files open in any image viewer and PDF files in any PDF
reader. No other software is needed.


5. Major component description
------------------------------
01_quality_control
  multiqc_report_pretrim_qc.html
      MultiQC 1.35 report of the Pre-trim QC module (FastQC 0.12.1 on the
      78 raw FASTQ files).
  multiqc_report_posttrim_qc.html
      MultiQC 1.35 report of the Post-trim QC module (FastQC 0.12.1 on the
      78 trimmed paired FASTQ files).
  multiqc_report_full_pipeline.html
      MultiQC report that aggregates the Trimmomatic, STAR and SAMtools
      logs of the whole run. It is the source of the trimming and alignment
      values in Tables S3a and S3c of the Supplementary Material. Its FastQC
      section was built from the raw reads, so multiqc_report_posttrim_qc.html
      should be used for the trimmed reads. Its HTSeq-count section was
      generated before the final quantification and does not match the
      count matrix. Use
      02_alignment_and_quantification/count_matrix_statistics.json for the
      quantification statistics.

02_alignment_and_quantification
  samtools-flagstat-table.csv
      SAMtools 1.22.1 flagstat summary of the duplicate-marked BAM files
      (values in millions of alignments).
  count_matrix_statistics.json
      HTSeq-count 2.0.5 statistics per sample (assigned, no_feature,
      ambiguous, alignment_not_unique, too_low_aQual and not_aligned pairs,
      features with counts and assignment rate). One trailing comma in the
      exported file was removed so that the file parses as standard JSON.
      No value was changed.
  annotated_counts_IPF.csv
      Merged count matrix after the Annotation module (features by
      samples), with the identifiers assigned by g:Profiler g:Convert.

03_sample_metadata
  IPF_meta_data.csv            Sample to group table used by the DEG
                               analysis module.
  SraRunTable_IPF_table1.csv   SRA run table of the 39 runs.
  SRR_Acc_List_IPF_data.txt    Accession list entered into the Upload
                               module.

04_differential_expression
  Outputs of the DEG analysis module (PyDESeq2 0.5.4, GSEApy 1.3.1 with
  Enrichr). The symbols in these files are as exported. For 127 tested
  features they are wrong, because g:Convert also matched the Swiss-Prot
  accessions in the namespace of an Agilent microarray (GPL19072).
  Supplementary Data S1 gives the corrected symbols (column Symbol) and
  marks these features (column Symbol_corrected). Log2 fold changes, Wald statistics and normalized enrichment
  scores are given as control relative to IPF (control as the numerator),
  as in the article and in Supplementary Data S1. Down-regulated features,
  with a negative log2FoldChange, are therefore raised in IPF.
  deseq2_full_results.csv      All 10,484 tested features (baseMean of 10
                               or more).
  DEGs_filtered.csv            The 3,464 differentially expressed features
                               (adjusted P below 0.05, absolute log2 fold
                               change above 0.5).
  DEGs_upregulated.csv         The 1,714 up-regulated features (positive
                               log2 fold change), which are reduced in IPF.
  DEGs_downregulated.csv       The 1,750 down-regulated features (negative
                               log2 fold change), which are raised in IPF.
  AllGenes_positiveLFC.csv     All tested features with a positive log2 fold
                               change.
  AllGenes_negativeLFC.csv     All tested features with a negative log2 fold
                               change.
  enrichment_results.csv       Enrichr over-representation analysis of the
                               100 most significant genes against
                               GO_Biological_Process_2023.
  gsea_results.csv             Preranked GSEA against
                               GO_Biological_Process_2023 (100 permutations).
  pca_plot.png, volcano_plot.png, ma_plot.png, clustermap.png,
  ora_barplot.png, ora_bubbleplot.png
                               Plots shown in Figs. 3 and 4 of the article
                               and in Fig. S4 of the Supplementary Material.
                               In these plots the IPF samples are labeled
                               Treatment.

05_alternative_splicing
  splicekit_report_IPF.html
      Self-contained report of the Gene Splicing module (splicekit 0.8.1
      with edgeR), contrast IPF versus control. Fold changes in this report
      are IPF relative to control, the opposite orientation to the DEG
      analysis module.

06_gene_fusions
  SRR51209xx_fusions.pdf
      Arriba 2.5.0 visualizations of the candidate fusion events, one PDF
      per sample and one page per event (271 events in 38 files).
      SRR5120922 had no retained event and therefore has no file.


6. Detailed setup instructions
------------------------------
No installation is needed. Unpack both archives with any ZIP tool into the
same place and keep the folder structure.


7. Detailed run instructions
----------------------------
The archives contain data and reports, not executable code. To repeat the
independent differential expression test of Section 2.5 of the article,
read 02_alignment_and_quantification/annotated_counts_IPF.csv and
03_sample_metadata/IPF_meta_data.csv into PyDESeq2 0.5.4. Use the Group
column of IPF_meta_data.csv (values Control and Idiopathic Pulmonary
Fibrosis) as the condition, with the design ~Condition and control as the
numerator. Set aside features with a baseMean below 10 and call features at
an adjusted P below 0.05 and an absolute log2 fold change above 0.5.
Section S4 of the Supplementary Material describes the procedure in full.
The analysis scripts that recompute the read metrics, the differential
expression test and the fusion tables from these files are provided as
Supplementary Data S3 (OmicsXplore_Data_S3.zip). Pass this folder to them
with --data OmicsXplore_Data_S2. The exported files are also archived on
Zenodo (https://doi.org/10.5281/zenodo.23507592).


8. Output description
---------------------
The test described above returns 10,484 tested features and 3,464
differentially expressed features, 1,714 up-regulated and 1,750
down-regulated in control relative to IPF. The comparison with the platform
for every feature is in the Reproduction sheet of Supplementary Data S1
(OmicsXplore_Data_S1.xlsx). Licenses and references for every engine are
listed in Table S1 of the Supplementary Material.


9. Contact information
----------------------
Md Ataul Islam, SilicoScientia Private Limited (Registered office),
Nagananda Commercial Complex, No. 07/3, 15/1, 18th Main Road, Jayanagar 9th
Block, Bengaluru 560041, India. E-mail address
ataul.islam@silicoscientia.com
